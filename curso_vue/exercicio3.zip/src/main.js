import Vue from 'vue'
import VueRouter from 'vue-router'
import App from './App.vue'
import Titulo from './components/titulo'
import Tabela from './components/tabela'
import Formulario from './components/formulario'

Vue.use(VueRouter)

Vue.config.productionTip = false

Vue.component('titulo', Titulo);
Vue.component('tabela', Tabela);
Vue.component('formulario', Formulario);

const routes = [
  {path: '/', name: 'home', component: App}, 
  {path: '/tabela', component: Tabela}, 
  {path: '/formulario', name: 'cadastro', component: Formulario},
]

const router = new VueRouter({
  mode: 'history', 
  routes
})

new Vue({
  //render: h => h(App),
  router
}).$mount('#app')
