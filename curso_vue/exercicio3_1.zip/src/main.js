import Vue from 'vue'
import App from './App.vue'
import Titulo from './components/titulo'
import Tabela from './components/tabela'
import Formulario from './components/formulario'

Vue.config.productionTip = false

Vue.component('titulo', Titulo);
Vue.component('tabela', Tabela);
Vue.component('formulario', Formulario);

new Vue({
  render: h => h(App),
}).$mount('#app')
