<template>
    <h1 :style="{color: cor}">{{texto}}</h1>
</template>

<script>
export default {
    props:["texto", "cor"]
}
</script>

<style>

</style>