<template>
    <table border="1" style="width: 100%" name="resultados">
           <thead>
               <tr>
                    <th scope="col">Nome</th>
                    <th scope="col">Cargo</th>
                    <th scope="col">Unidade</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="funcionario in funcionarios" :key="funcionario.id">
                    <td>{{funcionario.nome}}</td>
                    <td>{{funcionario.cargo}}</td>
                    <td>{{funcionario.unidade}}</td>
                </tr>
            </tbody>
       </table>
</template>

<script>
export default {
    props:["funcionarios"]
}
</script>

<style>

</style>